<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReEchantillon extends Model
{
    //
}
