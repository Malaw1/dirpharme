<div class="sidebar">
        <div class="sidebar-inner">
          <!-- ### $Sidebar Header ### -->
          <div class="sidebar-logo">
            <div class="peers ai-c fxw-nw">
              <div class="peer peer-greed">
                <a class="sidebar-link td-n" href="<?php echo e(url('home')); ?>">
                  <div class="peers ai-c fxw-nw">
                    <div class="peer">
                      <div class="logo">
                        <img src="<?php echo e(asset('img/logo_msas.png')); ?>" alt="">
                      </div>
                    </div>
                    <div class="peer peer-greed">
                      <h5 class="lh-1 mB-0 logo-text">Dirpharm</h5>
                    </div>
                  </div>
                </a>
              </div>
              <div class="peer">
                <div class="mobile-toggle sidebar-toggle">
                  <a href="" class="td-n">
                    <i class="ti-arrow-circle-left"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

        <ul class="sidebar-menu scrollable pos-r">
            <li class="nav-item mT-30 actived">
              <a class="sidebar-link" href="<?php echo e(url('home')); ?>">
                <span class="icon-holder">
                  <i class="c-blue-500 ti-home"></i>
                </span>
                <span class="title">Acceuil</span>
              </a>
            </li>
            <?php if(Auth()->check() && Auth()->user()->role == 'agence'): ?>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-blue-500 ti-file"></i>
                </span>
                <span class="title">Enregistrement</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-yellow-500 ti-pencil"></i>
                </span>
                <span class="title">Renouvellement</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-green-500 ti-settings"></i>
                </span>
                <span class="title">Variation</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-pink-500 ti-palette"></i>
                </span>
                <span class="title">Visa Publicitaire</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('events')); ?>">
                <span class="icon-holder">
                  <i class="c-deep-orange-500 ti-calendar"></i>
                </span>
                <span class="title">Calendrier</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('laboratoire')); ?>">
                <span class="icon-holder">
                  <i class="c-deep-purple-500 ti-comment-alt"></i>
                </span>
                <span class="title">Labo Representés</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('autorisation')); ?>">
                <span class="icon-holder">
                  <i class="c-indigo-500 ti-bar-chart"></i>
                </span>
                <span class="title">Autorisations</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('demande')); ?>">
                <span class="icon-holder">
                  <i class="c-light-blue-500 ti-folder"></i>
                </span>
                <span class="title">Demandes</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="#">
                <span class="icon-holder">
                  <i class="c-light-blue-500 ti-money"></i>
                </span>
                <span class="title">Factures</span>
              </a>
            </li>
            <?php elseif(Auth()->check() && Auth()->user()->role == 'labo'): ?>

            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-blue-500 ti-file"></i>
                </span>
                <span class="title">Enregistrement</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-yellow-500 ti-pencil"></i>
                </span>
                <span class="title">Renouvellement</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-green-500 ti-settings"></i>
                </span>
                <span class="title">Variation</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('request/create')); ?>">
                <span class="icon-holder">
                  <i class="c-pink-500 ti-palette"></i>
                </span>
                <span class="title">Visa Publicitaire</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('events')); ?>">
                <span class="icon-holder">
                  <i class="c-deep-orange-500 ti-calendar"></i>
                </span>
                <span class="title">Calendrier</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('autorisation')); ?>">
                <span class="icon-holder">
                  <i class="c-indigo-500 ti-bar-chart"></i>
                </span>
                <span class="title">Autorisations</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('demande')); ?>">
                <span class="icon-holder">
                  <i class="c-light-blue-500 ti-folder"></i>
                </span>
                <span class="title">Demandes</span>
              </a>
            </li>
            <?php elseif(Auth()->check() && Auth()->user()->role == 'pharmacien'): ?>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('evaluation')); ?>">
                <span class="icon-holder">
                  <i class="c-blue-500 ti-pencil"></i>
                </span>
                <span class="title">Evaluation</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('recevabilite')); ?>">
                <span class="icon-holder">
                  <i class="c-deep-orange-500 ti-calendar"></i>
                </span>
                <span class="title">Recevabilites</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('autorisation')); ?>">
                <span class="icon-holder">
                  <i class="c-indigo-500 ti-bar-chart"></i>
                </span>
                <span class="title">Autorisations</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('demande')); ?>">
                <span class="icon-holder">
                  <i class="c-light-yellow-500 ti-folder"></i>
                </span>
                <span class="title">Demandes</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('laboratoire')); ?>">
                <span class="icon-holder">
                  <i class="c-light-blue-500 ti-share"></i>
                </span>
                <span class="title">Laboratoires</span>
              </a>
            </li>
            <li class="nav-item">
              <a class='sidebar-link' href="<?php echo e(url('agence')); ?>">
                <span class="icon-holder">
                  <i class="c-light-blue-500 ti-share"></i>
                </span>
                <span class="title">Agences</span>
              </a>
            </li>

            <?php else: ?>
                <li class="nav-item">
                    <a class='sidebar-link' href="<?php echo e(url('users')); ?>">
                        <span class="icon-holder">
                        <i class="c-light-blue-500 ti-user"></i>
                        </span>
                        <span class="title">Users</span>
                    </a>
                </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
<?php /**PATH C:\Users\IT-Manager\Documents\20193073ev-Archive-v7\resources\views/partials/menu.blade.php ENDPATH**/ ?>