<script>
$('.file-upload').file_upload();
</script>
<?php $__env->startSection('content'); ?>
<div class="mT-30">
    <div class="jumbotron">
        <h1 class="display-5">Suivi de Votre Demande</h1>
        <p class="lead"><?php echo e($demande->type); ?> du produit: <strong><?php echo e($produit->nom_medicament); ?> <?php echo e($produit->forme_pharmaceutique); ?> </strong> du laboratoire <I><?php echo e($demande->labo); ?></I></p>
        <hr class="my-4">
        <?php if($demande->status != 'Acceptée'): ?>
            <div class="alert alert-warning">
                Status: <strong><?php echo e($demande->status); ?></strong>
            </div>
        <?php else: ?>
            <div class="alert alert-success">
                Status: <strong><?php echo e($demande->status); ?></strong>
            </div>
        <?php endif; ?>
        <p class="lead"></p>
    </div>



    <div class="card">
        <div class="card-header"><h3>Veuillez deposer votre dossier complet ici</h3></div>
        <div class="card-body">
            <form action="<?php echo e(route('dossier.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="custom-file">
                    <input type="file" class="custom-file-input form-control" id="customFile" name="modules">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                    <small>Ce dossier doit contenir tous les modules necessaire pour l'evaluation du dossier et doit etre compressé dans un fichier .zip ou .rar</small>
                    <br>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Manager\Documents\20193073ev-Archive-v7\resources\views/demande/create.blade.php ENDPATH**/ ?>