<?php echo e($data['message']); ?>

<?php /**PATH C:\Users\IT-Manager\Documents\20193073ev-Archive-v7\resources\views/mail/index.blade.php ENDPATH**/ ?>