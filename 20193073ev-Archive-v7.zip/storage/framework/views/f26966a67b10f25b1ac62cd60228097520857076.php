<script>
    $(document).ready(function(){
        $('#calendar-<?php echo e($id); ?>').fullCalendar(<?php echo $options; ?>);
    });
</script>
<?php /**PATH C:\Users\IT-Manager\Documents\20193073ev-Archive-v7\vendor\maddhatter\laravel-fullcalendar\src\MaddHatter\LaravelFullcalendar/../../views//script.blade.php ENDPATH**/ ?>