<?php $__env->startSection('content'); ?>
<div class="mT-30">
    <div class="card">
        <div class="card-header">
            <h4>Laboratoires</h4>
            <div class="pull-right text-right">
                <a href="<?php echo e(url('laboratoire/create')); ?>" class="btn btn-sm btn-primary">
                    <i  class="ion-plus-circled">Ajouter</i>
                </a>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <th>#</th>
                        <th>Laboratoire</th>
                        <th>Pays</th>
                        <th>Region</th>
                        <th>Adresse</th>
                        <th>Telephone</th>
                        <th>Email</th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $labo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($labo->name); ?></td>
                            <td><?php echo e($labo->pays); ?></td>
                            <td><?php echo e($labo->region); ?></td>
                            <td><?php echo e($labo->adresse); ?></td>
                            <td><?php echo e($labo->telephone); ?></td>
                            <td><?php echo e($labo->email); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Manager\Documents\20193073ev-Archive-v7\resources\views/laboratoire/index.blade.php ENDPATH**/ ?>