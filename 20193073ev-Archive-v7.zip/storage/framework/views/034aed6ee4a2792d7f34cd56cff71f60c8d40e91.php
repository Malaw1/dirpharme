<?php $__env->startSection('content'); ?>

<div class="bgc-white bd bdrs-3 p-20 mB-20">
        <h4 class="c-grey-900 mB-20">Recevabilite</h4>
        <table id="dataTable" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Nom du Produit</th>
                    <th>Labo Demandeur</th>
                    <th>Classe Therapeutique</th>
                    <th>Presentation</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Code</th>
                    <th>Nom du Produit</th>
                    <th>Labo Demandeur</th>
                    <th>Classe Therapeutique</th>
                    <th>Presentation</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
            <tbody>
                <?php $__currentLoopData = $received; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($receive->code); ?></td>
                    <td><?php echo e($receive->nom_medicament); ?></td>
                    <td><?php echo e($receive->labo); ?></td>
                    <td><?php echo e($receive->classe_therapeutique); ?></td>
                    <td><?php echo e($receive->presentation); ?></td>
                    <td><?php echo e($receive->status); ?></td>
                    <td>
                        <button class="item" disabled data-toggle="tooltip" data-placement="top" title="">
                            <i class=""><a href="<?php echo e(url('/recevabilite/create?id='. $receive->id)); ?>">Remplir la Grille</a></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Manager\Documents\20193073ev-Archive-v7\resources\views/recevabilite/index.blade.php ENDPATH**/ ?>