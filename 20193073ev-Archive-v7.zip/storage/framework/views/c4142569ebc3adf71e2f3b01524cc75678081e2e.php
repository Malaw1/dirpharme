<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css">

<div class="container">
    <?php if(Auth()->user()->role != 'pharmacien'): ?>
    <div class="panel panel-primary">
        <div class="panel-heading">Prise de Rendez-Vous</div>
            <div class="panel-body">
                <form action="<?php echo e(route('addEvent')); ?>" method="get" files="true">
                    <div class="col-xs-12">
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                        <?php elseif(Session::has('warning')): ?>
                            <div class="alert alert-danger"><?php echo e(Session::get('warning')); ?></div>
                        <?php endif; ?>
                    </div>



                <?php echo e(method_field('PATCH')); ?>

                <?php echo csrf_field(); ?>
                    <div class="col-xs-4 col-md-4 col-sm-4">
                        <label for="">Titre</label>
                        <input type="text" name="title" id="" class="form-control">
                        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-xs-4 col-md-4 col-sm-4">
                        <label for="">Date RV</label>
                        <input type="date" name="date" id="" class="form-control">
                        <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="col-xs-4 col-md-4 col-sm-4">
                        <label for=""></label>
                        <input type="hidden" name="demande_id" required value="5">
                        <input type="hidden" name="user_id" required value="<?php echo e(Auth()->user()->id); ?>">
                        <button type="submit" class="btn btn-primary">Valider</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="panel-primary panel">
        <div class="panel-heading">Mon Calendrier</div>
        <div class="panel-body">
        <div id='calendar'>
        <?php echo $calendar_details->calendar(); ?>

        <?php echo $calendar_details->script(); ?>

        </div>
        </div>
    </div>
    <?php else: ?>
    <br>  <br>  <br>  <br>
    <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <div class="float-right">
                      <form>
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search">
                          <div class="input-group-btn">
                            <button class="btn btn-secondary"><i class="ion ion-search"></i></button>
                          </div>
                        </div>
                      </form>
                    </div>
                    <h4>Demandes Reçues</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <tr>
                          <th class="text-center">
                            <div class="custom-checkbox custom-control">
                              <input type="checkbox" data-checkboxes="mygroup" data-checkbox-role="dad" class="custom-control-input" id="checkbox-all">
                              <label for="checkbox-all" class="custom-control-label"></label>
                            </div>
                          </th>
                          <th>Date</th>
                          <th>Motif</th>
                          <th>Demandeur</th>
                          <th>Action</th>
                        </tr>
                        <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td></td>
                                    <td><?php echo e($event->date); ?></td>
                                    <td><?php echo e($event->title); ?></td>
                                    <td><?php echo e($event->demandeur); ?></td>
                                    <td></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
    <?php endif; ?>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IT-Manager\Downloads\homologation-master(1)\homologation-master\resources\views/events/index.blade.php ENDPATH**/ ?>