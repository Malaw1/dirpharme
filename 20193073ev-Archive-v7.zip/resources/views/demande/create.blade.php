@extends('layouts.layout')
<script>
$('.file-upload').file_upload();
</script>
@section('content')
<div class="mT-30">
    <div class="jumbotron">
        <h1 class="display-5">Suivi de Votre Demande</h1>
        <p class="lead">{{ $demande->type}} du produit: <strong>{{ $produit->nom_medicament }} {{ $produit->forme_pharmaceutique }} </strong> du laboratoire <I>{{ $demande->labo }}</I></p>
        <hr class="my-4">
        @if($demande->status != 'Acceptée')
            <div class="alert alert-warning">
                Status: <strong>{{ $demande->status}}</strong>
            </div>
        @else
            <div class="alert alert-success">
                Status: <strong>{{ $demande->status}}</strong>
            </div>
        @endif
        <p class="lead"></p>
    </div>



    <div class="card">
        <div class="card-header"><h3>Veuillez deposer votre dossier complet ici</h3></div>
        <div class="card-body">
            <form action="{{ route('dossier.store')}}" method="post" enctype="multipart/form-data">
            @csrf
                <div class="custom-file">
                    <input type="file" class="custom-file-input form-control" id="customFile" name="modules">
                    <label class="custom-file-label" for="customFile">Choose file</label>
                    <small>Ce dossier doit contenir tous les modules necessaire pour l'evaluation du dossier et doit etre compressé dans un fichier .zip ou .rar</small>
                    <br>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>

</div>

@endsection
